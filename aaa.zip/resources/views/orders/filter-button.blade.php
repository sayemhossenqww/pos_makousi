<button class="btn btn-primary ms-auto px-2 py-1 text-center" data-bs-toggle="modal"
    data-bs-target="#filterModal">
    <i class="bi bi-funnel align-middle"></i> Filter
</button>
