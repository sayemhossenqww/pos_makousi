<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Status Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'active' => 'Active',
    'inactive' => 'Inactive',

    'available' => 'Available',
    'unavailable' => 'Unavailable',

];
