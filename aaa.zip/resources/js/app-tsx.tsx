// import React from "react";
// import { render } from "react-dom";
// import PointOfSale from "./components/PointOfSale";
// render(<PointOfSale />, document.getElementById("pos"));
