declare class ApiService {
    apiUrl(uri: string): string;
}
declare const _default: ApiService;
export default _default;
