export interface ICustomer {
    id: string,
    name: string,
    email: string,
    mobile: string,
}