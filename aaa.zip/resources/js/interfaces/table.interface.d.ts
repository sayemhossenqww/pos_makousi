export interface ITable {
    id: string;
    name: string;
}
