export const __esModule: boolean;
